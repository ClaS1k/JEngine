$(function(){
	$('#book_marks').delegate('#custom_menu_darkness_nav_button:not(.current)', 'click', function(){
		$(this).addClass('current').siblings().removeClass('current')
		 .parents('#book_marksbox').find('.book_markbox').hide().eq($(this).index()).fadeIn(500);
	});
});
